import 'package:flutter/material.dart';
import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gather/app/home/home.dart';

final helloWorldProvider = Provider((_) => 'Hello world');
final provider = StateNotifierProvider<NavigationNotifier, PageModel>((ref) => NavigationNotifier());

void main() {
  runApp(const ProviderScope(child:MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      themeMode: ThemeMode.light,
      theme: FlexThemeData.light(scheme: FlexScheme.damask),
      darkTheme: FlexThemeData.dark(scheme: FlexScheme.damask),
      home: Home(),
    );
  }
}

class MyNavigationPage extends ConsumerWidget {
  const MyNavigationPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context, WidgetRef ref) {

    final String value = ref.watch(helloWorldProvider);
    PageModel pagemodel = ref.watch(provider);
    int pageno = 0;
    if (pagemodel.page == NavigationBarEvent.HOME) {
      pageno = 0;
    } else if (pagemodel.page == NavigationBarEvent.PROFIL) {
      pageno = 1;
    }
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: Text(value)),
        body: Center(
          child: Text(value),
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label : "home"
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: "Settings")
          ],
          currentIndex: pageno,
          onTap : ref.read(provider.notifier).selectPage,
        )
      ),
    );
  }
}


enum NavigationBarEvent {HOME, PROFIL}

class NavigationNotifier extends StateNotifier<PageModel> {
  NavigationNotifier() : super(defaultPage);

  static const defaultPage = PageModel(NavigationBarEvent.HOME);

  void selectPage(int i){
    switch (i) {
      case 0:
        state = const PageModel(NavigationBarEvent.HOME);
        break;
      case 1:
        state = const PageModel(NavigationBarEvent.PROFIL);
        break;
    }
  }
}

class PageModel {
  const PageModel(this.page);
  final NavigationBarEvent page;
}