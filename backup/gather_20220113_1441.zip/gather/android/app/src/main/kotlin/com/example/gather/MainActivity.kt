package com.example.gather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
